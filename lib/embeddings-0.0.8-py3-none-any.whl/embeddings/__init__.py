from embeddings.word2vec import Word2VecEmbedding
from embeddings.glove import GloveEmbedding
from embeddings.fasttext import FastTextEmbedding
from embeddings.kazuma import KazumaCharEmbedding
